import { Request, Response } from 'express';
import { createUser, getAllUsers } from '../services/user.service';
import { DatabaseError } from '../errors';
import { createUserSchema, getUsersQuerySchema } from '../models/user.schema';

export const createUserHandler = async (req: Request, res: Response) => {
    try {
        const { firstName, lastName, email, phone } = createUserSchema.parse(req.body);

        const createdUser = await createUser({
            firstName,
            lastName,
            email,
            phone,
        });
        res.send(createdUser).status(201);
    } catch (error) {
        if (error instanceof DatabaseError) {
            return res.status(500).send({ message: error.message });
        }
        throw error;
    }
};

export const getUsersHandler = async (req: Request, res: Response) => {
    try {
        const validatedQuery = getUsersQuerySchema.parse(req.query);

        const users = await getAllUsers(
            validatedQuery.skip,
            validatedQuery.limit,
            validatedQuery.created,
        );
        res.send(users).status(200);
    } catch (error) {
        if (error instanceof DatabaseError) {
            res.status(500).send({ message: error.message });
        }
        throw error;
    }
};
