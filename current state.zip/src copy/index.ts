import express, { Express, Request, Response, NextFunction } from 'express';
import { userRouter } from './routers/user.router';
import * as dotenv from 'dotenv';
import cors from 'cors';
import { logger } from './config/logger';
import pinoHttp from 'pino-http';

dotenv.config();

const app: Express = express();

app.use(pinoHttp({ logger }));
app.use(cors()).use(express.json()).options('*', cors());

app.use('/users', userRouter);

app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    logger.error(err);
    res.status(500).send({ message: 'Internal Server Error' });
});

app.get('/health', (_req: Request, res: Response) => {
    res.status(200).send({ status: 'UP' });
});

const port = process.env.PORT || 3111;
app.listen(port, () => {
    logger.info(`[server]: Server is running at http://localhost:${port}`);
});

// Graceful Shutdown // TODO: close database connection here.
process.on('SIGINT', () => {
    logger.info('SIGINT signal received. Closing server...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    logger.info('SIGTERM signal received. Closing server...');
    process.exit(0);
});
