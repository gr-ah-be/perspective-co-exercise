import { logger } from '../config/logger';
import { IUser, CreateUserDto } from '../models/user.model';
import { UserRepository } from '../repositories/user.repository';
import { MongooseError } from 'mongoose';
import { DatabaseError } from '../errors';

const userRepository = new UserRepository();

export const createUser = async (user: CreateUserDto): Promise<IUser> => {
    try {
        return await userRepository.create(user);
    } catch (error) {
        if (error instanceof MongooseError) {
            logger.error(error, 'Error occured while creating user');
            throw new DatabaseError(error.message);
        }
        throw error;
    }
};

export const getAllUsers = async (
    skip: number,
    limit: number,
    createdAtSortOrder: 'asc' | 'desc',
): Promise<IUser[]> => {
    try {
        return await userRepository.findAll(skip, limit, createdAtSortOrder);
    } catch (error) {
        if (error instanceof MongooseError) {
            logger.error(error, 'Error occured while getting users');
            throw new DatabaseError(error.message);
        }
        throw error;
    }
};
