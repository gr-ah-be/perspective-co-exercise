import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { logger } from './logger';

dotenv.config();

const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/backend-test';
const dbConnection = mongoose.connection;

// TODO: check if need to use/export dbConnection
mongoose
    .connect(mongoUri)
    .then(() => {
        logger.info('Connected to MongoDB');
    })
    .catch((err) => {
        logger.error('Failed to connect to MongoDB:', err);
    });
